# silverpos

#Introduction

This repository is designed to host the code and all additional files required to successfully complete the POS system tutorials hosted on youtube
